require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");

const { testConnection } = require("./database/db");
const { checkPythonService } = require("./services/pythonNlpService");

const usersRoutes = require("./routes/usersRoutes");
const psychologistsRoutes = require("./routes/psychologistsRoutes");
const conversationsRoutes = require("./routes/conversationsRoutes");
const recommendationsRoutes = require("./routes/recommendationsRoutes");
const appointmentsRoutes = require("./routes/appointmentsRoutes");
const paymentsRoutes = require("./routes/paymentsRoutes");
const adminRoutes = require("./routes/adminRoutes");
const { ensureDefaultAdmin } = require("./services/adminSeedService");
const app = express();
const PORT = process.env.PORT || 4000;

app.use(helmet());
app.use(compression());

app.use(
  cors({
    origin: [
      process.env.FRONTEND_URL || "http://localhost:3000",
      "http://127.0.0.1:3000",
    ],
    credentials: true,
  })
);

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "ACA Node.js Backend running",
  });
});

app.get("/api/health", async (req, res) => {
  try {
    await testConnection();

    res.json({
      success: true,
      service: "node-backend",
      database: "connected",
      status: "running",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      service: "node-backend",
      database: "disconnected",
      message: error.message,
    });
  }
});

app.get("/api/health/python", async (req, res) => {
  try {
    const python = await checkPythonService();

    res.json({
      success: true,
      node: "running",
      python,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "FastAPI Python indisponible",
      error: error.message,
    });
  }
});

app.use("/api/users", usersRoutes);
app.use("/api/conversations", conversationsRoutes);
app.use("/api/psychologists", psychologistsRoutes);
app.use("/api/recommendations", recommendationsRoutes);
app.use("/api/appointments", appointmentsRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/admin", adminRoutes);
// 404 après toutes les routes
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route introuvable",
  });
});

app.use((err, req, res, next) => {
  console.error("❌ Server error:", err);

  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Erreur serveur",
  });
});

async function startServer() {
  try {
    await testConnection();

    app.listen(PORT, () => {
      console.log(`✅ Backend Node.js lancé sur http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("❌ Erreur lancement backend :", error.message);
    process.exit(1);
  }
}

startServer();