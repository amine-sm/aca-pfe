const { query } = require("../database/db");

// =======================
// CREATE APPOINTMENT USER
// =======================
async function createAppointment(req, res) {
  try {
    const userId = req.auth.id;

    const {
      psychologist_id,
      appointment_date,
      duration_minutes,
      mode,
      notes,
    } = req.body;

    if (!psychologist_id || !appointment_date) {
      return res.status(400).json({
        success: false,
        message: "psychologist_id et appointment_date sont obligatoires",
      });
    }

    const psychologists = await query(
      `
      SELECT *
      FROM psychologists
      WHERE id = ?
        AND is_active = TRUE
        AND is_verified = TRUE
      `,
      [psychologist_id]
    );

    if (psychologists.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Psychologue introuvable ou non validé",
      });
    }

    const psychologist = psychologists[0];

    // Vérifier si le user est affecté à ce psychologue
    const assignments = await query(
      `
      SELECT *
      FROM psychologist_assignments
      WHERE user_id = ?
        AND psychologist_id = ?
        AND status = 'active'
      `,
      [userId, psychologist_id]
    );

    if (assignments.length === 0) {
      return res.status(403).json({
        success: false,
        message:
          "Vous devez d'abord accepter ce psychologue avant de prendre un rendez-vous",
      });
    }

    // Vérifier si le psychologue a déjà un rendez-vous à cette date
    const existingAppointments = await query(
      `
      SELECT id
      FROM appointments
      WHERE psychologist_id = ?
        AND appointment_date = ?
        AND status NOT IN ('cancelled', 'no_show')
      `,
      [psychologist_id, appointment_date]
    );

    if (existingAppointments.length > 0) {
      return res.status(409).json({
        success: false,
        message: "Ce créneau est déjà réservé",
      });
    }

    const result = await query(
      `
      INSERT INTO appointments (
        user_id,
        psychologist_id,
        appointment_date,
        duration_minutes,
        mode,
        status,
        payment_status,
        price,
        currency,
        notes
      )
      VALUES (?, ?, ?, ?, ?, 'pending_payment', 'unpaid', ?, ?, ?)
      `,
      [
        userId,
        psychologist_id,
        appointment_date,
        Number(duration_minutes || 45),
        mode || "online",
        Number(psychologist.consultation_price || 0),
        psychologist.currency || "DZD",
        notes || null,
      ]
    );

    await query(
      `
      INSERT INTO notifications (
        receiver_type,
        receiver_id,
        title,
        message,
        type,
        is_read
      )
      VALUES ('psychologist', ?, ?, ?, 'appointment', FALSE)
      `,
      [
        psychologist_id,
        "Nouveau rendez-vous",
        "Un utilisateur a demandé un rendez-vous avec vous.",
      ]
    );

    return res.status(201).json({
      success: true,
      message: "Rendez-vous créé avec succès. Paiement requis.",
      appointment: {
        id: result.insertId,
        user_id: userId,
        psychologist_id,
        appointment_date,
        duration_minutes: Number(duration_minutes || 45),
        mode: mode || "online",
        status: "pending_payment",
        payment_status: "unpaid",
        price: Number(psychologist.consultation_price || 0),
        currency: psychologist.currency || "DZD",
      },
    });
  } catch (error) {
    console.error("Erreur createAppointment:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur création rendez-vous",
      error: error.message,
    });
  }
}

// =======================
// GET MY APPOINTMENTS USER
// =======================
async function getMyAppointments(req, res) {
  try {
    const userId = req.auth.id;

    const appointments = await query(
      `
      SELECT
        a.*,

        p.full_name AS psychologist_name,
        p.email AS psychologist_email,
        p.phone AS psychologist_phone,
        p.specialization,
        p.city AS psychologist_city,
        p.languages AS psychologist_languages
      FROM appointments a
      JOIN psychologists p ON p.id = a.psychologist_id
      WHERE a.user_id = ?
      ORDER BY a.appointment_date DESC
      `,
      [userId]
    );

    return res.json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error("Erreur getMyAppointments:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous user",
      error: error.message,
    });
  }
}

// =======================
// GET ONE APPOINTMENT USER
// =======================
async function getMyAppointmentById(req, res) {
  try {
    const userId = req.auth.id;
    const { id } = req.params;

    const appointments = await query(
      `
      SELECT
        a.*,

        p.full_name AS psychologist_name,
        p.email AS psychologist_email,
        p.phone AS psychologist_phone,
        p.specialization,
        p.city AS psychologist_city
      FROM appointments a
      JOIN psychologists p ON p.id = a.psychologist_id
      WHERE a.id = ?
        AND a.user_id = ?
      `,
      [id, userId]
    );

    if (appointments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Rendez-vous introuvable",
      });
    }

    return res.json({
      success: true,
      appointment: appointments[0],
    });
  } catch (error) {
    console.error("Erreur getMyAppointmentById:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous",
      error: error.message,
    });
  }
}

// =======================
// CANCEL APPOINTMENT USER
// =======================
async function cancelMyAppointment(req, res) {
  try {
    const userId = req.auth.id;
    const { id } = req.params;

    const appointments = await query(
      `
      SELECT *
      FROM appointments
      WHERE id = ?
        AND user_id = ?
      `,
      [id, userId]
    );

    if (appointments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Rendez-vous introuvable",
      });
    }

    const appointment = appointments[0];

    if (appointment.status === "completed") {
      return res.status(400).json({
        success: false,
        message: "Impossible d’annuler un rendez-vous terminé",
      });
    }

    await query(
      `
      UPDATE appointments
      SET status = 'cancelled'
      WHERE id = ?
        AND user_id = ?
      `,
      [id, userId]
    );

    await query(
      `
      INSERT INTO notifications (
        receiver_type,
        receiver_id,
        title,
        message,
        type,
        is_read
      )
      VALUES ('psychologist', ?, ?, ?, 'appointment', FALSE)
      `,
      [
        appointment.psychologist_id,
        "Rendez-vous annulé",
        "Un utilisateur a annulé son rendez-vous.",
      ]
    );

    return res.json({
      success: true,
      message: "Rendez-vous annulé avec succès",
    });
  } catch (error) {
    console.error("Erreur cancelMyAppointment:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur annulation rendez-vous",
      error: error.message,
    });
  }
}

// =======================
// GET APPOINTMENTS PSYCHOLOGIST
// =======================
async function getPsychologistAppointments(req, res) {
  try {
    const psychologistId = req.auth.id;

    const appointments = await query(
      `
      SELECT
        a.*,

        u.full_name AS user_name,
        u.email AS user_email,
        u.phone AS user_phone,
        u.city AS user_city,
        u.risk_level,
        u.addiction_type,
        u.consumption_level
      FROM appointments a
      JOIN users u ON u.id = a.user_id
      WHERE a.psychologist_id = ?
      ORDER BY a.appointment_date DESC
      `,
      [psychologistId]
    );

    return res.json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error("Erreur getPsychologistAppointments:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous psychologue",
      error: error.message,
    });
  }
}

// =======================
// GET ONE APPOINTMENT PSYCHOLOGIST
// =======================
async function getPsychologistAppointmentById(req, res) {
  try {
    const psychologistId = req.auth.id;
    const { id } = req.params;

    const appointments = await query(
      `
      SELECT
        a.*,

        u.full_name AS user_name,
        u.email AS user_email,
        u.phone AS user_phone,
        u.city AS user_city,
        u.risk_level,
        u.addiction_type,
        u.consumption_level
      FROM appointments a
      JOIN users u ON u.id = a.user_id
      WHERE a.id = ?
        AND a.psychologist_id = ?
      `,
      [id, psychologistId]
    );

    if (appointments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Rendez-vous introuvable",
      });
    }

    return res.json({
      success: true,
      appointment: appointments[0],
    });
  } catch (error) {
    console.error("Erreur getPsychologistAppointmentById:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous psychologue",
      error: error.message,
    });
  }
}

// =======================
// UPDATE APPOINTMENT STATUS PSYCHOLOGIST
// =======================
async function updateAppointmentStatus(req, res) {
  try {
    const psychologistId = req.auth.id;
    const { id } = req.params;
    const { status } = req.body;

    const allowed = ["confirmed", "completed", "cancelled", "no_show"];

    if (!allowed.includes(status)) {
      return res.status(400).json({
        success: false,
        message:
          "Statut invalide. Utilisez confirmed, completed, cancelled ou no_show",
      });
    }

    const appointments = await query(
      `
      SELECT *
      FROM appointments
      WHERE id = ?
        AND psychologist_id = ?
      `,
      [id, psychologistId]
    );

    if (appointments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Rendez-vous introuvable",
      });
    }

    await query(
      `
      UPDATE appointments
      SET status = ?
      WHERE id = ?
        AND psychologist_id = ?
      `,
      [status, id, psychologistId]
    );

    await query(
      `
      INSERT INTO notifications (
        receiver_type,
        receiver_id,
        title,
        message,
        type,
        is_read
      )
      VALUES ('user', ?, ?, ?, 'appointment', FALSE)
      `,
      [
        appointments[0].user_id,
        "Statut rendez-vous modifié",
        `Votre rendez-vous est maintenant : ${status}.`,
      ]
    );

    return res.json({
      success: true,
      message: "Statut rendez-vous mis à jour",
    });
  } catch (error) {
    console.error("Erreur updateAppointmentStatus:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur modification statut rendez-vous",
      error: error.message,
    });
  }
}

// =======================
// ADMIN GET ALL APPOINTMENTS
// =======================
async function getAllAppointmentsAdmin(req, res) {
  try {
    const appointments = await query(
      `
      SELECT
        a.*,

        u.full_name AS user_name,
        u.email AS user_email,

        p.full_name AS psychologist_name,
        p.email AS psychologist_email
      FROM appointments a
      JOIN users u ON u.id = a.user_id
      JOIN psychologists p ON p.id = a.psychologist_id
      ORDER BY a.appointment_date DESC
      `
    );

    return res.json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error("Erreur getAllAppointmentsAdmin:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous admin",
      error: error.message,
    });
  }
}

module.exports = {
  createAppointment,
  getMyAppointments,
  getMyAppointmentById,
  cancelMyAppointment,
  getPsychologistAppointments,
  getPsychologistAppointmentById,
  updateAppointmentStatus,
  getAllAppointmentsAdmin,
};