const { query, transaction } = require("../database/db");

// =======================
// GET PLANS
// =======================
async function getPlans(req, res) {
  try {
    const plans = await query(
      `
      SELECT *
      FROM plans
      WHERE is_active = TRUE
      ORDER BY price ASC
      `
    );

    return res.json({
      success: true,
      plans,
    });
  } catch (error) {
    console.error("Erreur getPlans:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération plans",
      error: error.message,
    });
  }
}

// =======================
// CREATE CHECKOUT
// Paiement manuel pour appointment ou plan
// =======================
async function createCheckout(req, res) {
  try {
    const userId = req.auth.id;

    const {
      appointment_id,
      plan_id,
      provider,
      payment_method,
      proof_reference,
      notes,
    } = req.body;

    let amount = 0;
    let psychologistId = null;
    let finalAppointmentId = appointment_id || null;
    let finalPlanId = plan_id || null;
    let description = "";

    // =======================
    // Paiement rendez-vous
    // =======================
    if (appointment_id) {
      const appointments = await query(
        `
        SELECT *
        FROM appointments
        WHERE id = ?
          AND user_id = ?
        `,
        [appointment_id, userId]
      );

      if (appointments.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Rendez-vous introuvable",
        });
      }

      const appointment = appointments[0];

      if (appointment.payment_status === "paid") {
        return res.status(409).json({
          success: false,
          message: "Ce rendez-vous est déjà payé",
        });
      }

      amount = Number(appointment.price || 0);
      psychologistId = appointment.psychologist_id;
      description = `Paiement rendez-vous #${appointment.id}`;
    }

    // =======================
    // Paiement plan
    // =======================
    else if (plan_id) {
      const plans = await query(
        `
        SELECT *
        FROM plans
        WHERE id = ?
          AND is_active = TRUE
        `,
        [plan_id]
      );

      if (plans.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Plan introuvable",
        });
      }

      const plan = plans[0];

      amount = Number(plan.price || 0);
      description = `Paiement plan : ${plan.name}`;
    }

    else {
      return res.status(400).json({
        success: false,
        message: "appointment_id ou plan_id obligatoire",
      });
    }

    const selectedProvider = provider || process.env.PAYMENT_PROVIDER || "manual";
    const selectedMethod = payment_method || "manual";

    const providerPaymentId = `${selectedProvider}_${Date.now()}_${userId}`;

    const checkoutUrl =
      `${process.env.FRONTEND_URL || "http://localhost:3000"}/payment/manual/${providerPaymentId}`;

    const result = await query(
      `
      INSERT INTO payments (
        user_id,
        psychologist_id,
        appointment_id,
        plan_id,
        provider,
        provider_payment_id,
        provider_checkout_url,
        amount,
        currency,
        status,
        payment_method,
        metadata
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'DZD', 'pending', ?, ?)
      `,
      [
        userId,
        psychologistId,
        finalAppointmentId,
        finalPlanId,
        selectedProvider,
        providerPaymentId,
        checkoutUrl,
        amount,
        selectedMethod,
        JSON.stringify({
          description,
          proof_reference: proof_reference || null,
          notes: notes || null,
          source: appointment_id ? "appointment" : "plan",
        }),
      ]
    );

    return res.status(201).json({
      success: true,
      message: "Paiement créé avec succès",
      payment: {
        id: result.insertId,
        provider: selectedProvider,
        provider_payment_id: providerPaymentId,
        checkout_url: checkoutUrl,
        amount,
        currency: "DZD",
        status: "pending",
        payment_method: selectedMethod,
        description,
      },
    });
  } catch (error) {
    console.error("Erreur createCheckout:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur création paiement",
      error: error.message,
    });
  }
}

// =======================
// GET MY PAYMENTS
// =======================
async function getMyPayments(req, res) {
  try {
    const payments = await query(
      `
      SELECT
        p.*,
        a.appointment_date,
        a.mode AS appointment_mode,
        psy.full_name AS psychologist_name,
        pl.name AS plan_name
      FROM payments p
      LEFT JOIN appointments a ON a.id = p.appointment_id
      LEFT JOIN psychologists psy ON psy.id = p.psychologist_id
      LEFT JOIN plans pl ON pl.id = p.plan_id
      WHERE p.user_id = ?
      ORDER BY p.created_at DESC
      `,
      [req.auth.id]
    );

    return res.json({
      success: true,
      payments,
    });
  } catch (error) {
    console.error("Erreur getMyPayments:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération paiements",
      error: error.message,
    });
  }
}

// =======================
// GET PAYMENT BY ID USER
// =======================
async function getMyPaymentById(req, res) {
  try {
    const userId = req.auth.id;
    const { id } = req.params;

    const payments = await query(
      `
      SELECT
        p.*,
        a.appointment_date,
        a.mode AS appointment_mode,
        psy.full_name AS psychologist_name,
        pl.name AS plan_name
      FROM payments p
      LEFT JOIN appointments a ON a.id = p.appointment_id
      LEFT JOIN psychologists psy ON psy.id = p.psychologist_id
      LEFT JOIN plans pl ON pl.id = p.plan_id
      WHERE p.id = ?
        AND p.user_id = ?
      `,
      [id, userId]
    );

    if (payments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Paiement introuvable",
      });
    }

    return res.json({
      success: true,
      payment: payments[0],
    });
  } catch (error) {
    console.error("Erreur getMyPaymentById:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération paiement",
      error: error.message,
    });
  }
}

// =======================
// GET MY INVOICES
// =======================
async function getMyInvoices(req, res) {
  try {
    const invoices = await query(
      `
      SELECT
        i.*,
        p.provider,
        p.payment_method,
        p.status AS payment_status
      FROM invoices i
      LEFT JOIN payments p ON p.id = i.payment_id
      WHERE i.user_id = ?
      ORDER BY i.issued_at DESC
      `,
      [req.auth.id]
    );

    return res.json({
      success: true,
      invoices,
    });
  } catch (error) {
    console.error("Erreur getMyInvoices:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération factures",
      error: error.message,
    });
  }
}

// =======================
// ADMIN VALIDATE MANUAL PAYMENT
// =======================
async function markManualPaid(req, res) {
  try {
    const { id } = req.params;

    const result = await transaction(async (connection) => {
      const [payments] = await connection.execute(
        `
        SELECT *
        FROM payments
        WHERE id = ?
        `,
        [id]
      );

      if (payments.length === 0) {
        throw new Error("Paiement introuvable");
      }

      const payment = payments[0];

      if (payment.status === "paid") {
        throw new Error("Ce paiement est déjà payé");
      }

      // 1. Paiement payé
      await connection.execute(
        `
        UPDATE payments
        SET status = 'paid',
            paid_at = NOW()
        WHERE id = ?
        `,
        [id]
      );

      // 2. Si paiement rendez-vous => confirmer rendez-vous
      if (payment.appointment_id) {
        await connection.execute(
          `
          UPDATE appointments
          SET status = 'confirmed',
              payment_status = 'paid'
          WHERE id = ?
          `,
          [payment.appointment_id]
        );
      }

      // 3. Créer facture
      const invoiceNumber = `INV-${Date.now()}-${payment.id}`;

      await connection.execute(
        `
        INSERT INTO invoices (
          user_id,
          payment_id,
          invoice_number,
          amount,
          currency,
          status
        )
        VALUES (?, ?, ?, ?, ?, 'paid')
        `,
        [
          payment.user_id,
          payment.id,
          invoiceNumber,
          payment.amount,
          payment.currency || "DZD",
        ]
      );

      // 4. Si paiement lié à psychologue => créer payout
      if (payment.psychologist_id) {
        const feePercent = Number(process.env.PLATFORM_FEE_PERCENT || 15);
        const grossAmount = Number(payment.amount || 0);
        const platformFee = (grossAmount * feePercent) / 100;
        const netAmount = grossAmount - platformFee;

        await connection.execute(
          `
          INSERT INTO psychologist_payouts (
            psychologist_id,
            payment_id,
            gross_amount,
            platform_fee,
            net_amount,
            status
          )
          VALUES (?, ?, ?, ?, ?, 'pending')
          `,
          [
            payment.psychologist_id,
            payment.id,
            grossAmount,
            platformFee,
            netAmount,
          ]
        );
      }

      // 5. Notification user
      await connection.execute(
        `
        INSERT INTO notifications (
          receiver_type,
          receiver_id,
          title,
          message,
          type,
          is_read
        )
        VALUES ('user', ?, ?, ?, 'payment', FALSE)
        `,
        [
          payment.user_id,
          "Paiement validé",
          "Votre paiement a été validé avec succès.",
        ]
      );

      // 6. Notification psychologue si existe
      if (payment.psychologist_id) {
        await connection.execute(
          `
          INSERT INTO notifications (
            receiver_type,
            receiver_id,
            title,
            message,
            type,
            is_read
          )
          VALUES ('psychologist', ?, ?, ?, 'payment', FALSE)
          `,
          [
            payment.psychologist_id,
            "Paiement reçu",
            "Un paiement lié à un rendez-vous a été validé.",
          ]
        );
      }

      return {
        invoice_number: invoiceNumber,
      };
    });

    return res.json({
      success: true,
      message: "Paiement validé manuellement avec succès",
      invoice_number: result.invoice_number,
    });
  } catch (error) {
    console.error("Erreur markManualPaid:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur validation paiement",
      error: error.message,
    });
  }
}

// =======================
// ADMIN REJECT PAYMENT
// =======================
async function rejectPayment(req, res) {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const payments = await query(
      `
      SELECT *
      FROM payments
      WHERE id = ?
      `,
      [id]
    );

    if (payments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Paiement introuvable",
      });
    }

    if (payments[0].status === "paid") {
      return res.status(400).json({
        success: false,
        message: "Impossible de refuser un paiement déjà payé",
      });
    }

    await query(
      `
      UPDATE payments
      SET status = 'failed',
          metadata = JSON_SET(
            COALESCE(metadata, JSON_OBJECT()),
            '$.reject_reason',
            ?
          )
      WHERE id = ?
      `,
      [reason || "Paiement refusé par admin", id]
    );

    await query(
      `
      INSERT INTO notifications (
        receiver_type,
        receiver_id,
        title,
        message,
        type,
        is_read
      )
      VALUES ('user', ?, ?, ?, 'payment', FALSE)
      `,
      [
        payments[0].user_id,
        "Paiement refusé",
        reason || "Votre paiement a été refusé.",
      ]
    );

    return res.json({
      success: true,
      message: "Paiement refusé",
    });
  } catch (error) {
    console.error("Erreur rejectPayment:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur refus paiement",
      error: error.message,
    });
  }
}

// =======================
// ADMIN GET ALL PAYMENTS
// =======================
async function getAllPaymentsAdmin(req, res) {
  try {
    const payments = await query(
      `
      SELECT
        p.*,
        u.full_name AS user_name,
        u.email AS user_email,
        psy.full_name AS psychologist_name,
        pl.name AS plan_name
      FROM payments p
      LEFT JOIN users u ON u.id = p.user_id
      LEFT JOIN psychologists psy ON psy.id = p.psychologist_id
      LEFT JOIN plans pl ON pl.id = p.plan_id
      ORDER BY p.created_at DESC
      `
    );

    return res.json({
      success: true,
      payments,
    });
  } catch (error) {
    console.error("Erreur getAllPaymentsAdmin:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération paiements admin",
      error: error.message,
    });
  }
}

// =======================
// PSYCHOLOGIST GET MY PAYOUTS
// =======================
async function getMyPayouts(req, res) {
  try {
    const payouts = await query(
      `
      SELECT
        pp.*,
        p.amount AS payment_amount,
        p.status AS payment_status,
        p.created_at AS payment_created_at
      FROM psychologist_payouts pp
      JOIN payments p ON p.id = pp.payment_id
      WHERE pp.psychologist_id = ?
      ORDER BY pp.created_at DESC
      `,
      [req.auth.id]
    );

    return res.json({
      success: true,
      payouts,
    });
  } catch (error) {
    console.error("Erreur getMyPayouts:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération revenus psychologue",
      error: error.message,
    });
  }
}

// =======================
// PAYMENT WEBHOOK
// Pour plus tard : Chargily / Stripe / autre
// =======================
async function webhookPayment(req, res) {
  try {
    const { provider } = req.params;
    const payload = req.body || {};

    await query(
      `
      INSERT INTO payment_webhooks (
        provider,
        event_type,
        provider_payment_id,
        payload,
        processed
      )
      VALUES (?, ?, ?, ?, FALSE)
      `,
      [
        provider,
        payload.type || payload.event || "payment_event",
        payload.id || payload.payment_id || payload.checkout_id || null,
        JSON.stringify(payload),
      ]
    );

    return res.json({
      success: true,
      message: "Webhook paiement reçu",
    });
  } catch (error) {
    console.error("Erreur webhookPayment:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur webhook paiement",
      error: error.message,
    });
  }
}

module.exports = {
  getPlans,
  createCheckout,
  getMyPayments,
  getMyPaymentById,
  getMyInvoices,
  markManualPaid,
  rejectPayment,
  getAllPaymentsAdmin,
  getMyPayouts,
  webhookPayment,
};