const bcrypt = require("bcryptjs");
const { query } = require("../database/db");
const { generateToken } = require("../utils/jwt");

// =======================
// LOGIN ADMIN
// =======================
async function loginAdmin(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email et mot de passe obligatoires",
      });
    }

    const admins = await query(
      `
      SELECT *
      FROM admins
      WHERE email = ?
        AND is_active = TRUE
      `,
      [email]
    );

    if (admins.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Identifiants incorrects",
      });
    }

    const admin = admins[0];

    const ok = await bcrypt.compare(password, admin.password_hash);

    if (!ok) {
      return res.status(401).json({
        success: false,
        message: "Identifiants incorrects",
      });
    }

    const token = generateToken({
      id: admin.id,
      role: admin.role || "ADMIN",
    });

    delete admin.password_hash;

    let permissions = admin.permissions;

    try {
      permissions =
        typeof admin.permissions === "string"
          ? JSON.parse(admin.permissions)
          : admin.permissions;
    } catch {
      permissions = {};
    }

    return res.json({
      success: true,
      message: "Connexion admin réussie",
      token,
      admin: {
        ...admin,
        permissions,
      },
    });
  } catch (error) {
    console.error("Erreur loginAdmin:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur connexion admin",
      error: error.message,
    });
  }
}

// =======================
// ADMIN PROFILE
// =======================
async function getAdminProfile(req, res) {
  try {
    return res.json({
      success: true,
      admin: req.admin,
    });
  } catch (error) {
    console.error("Erreur getAdminProfile:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération profil admin",
      error: error.message,
    });
  }
}

// =======================
// DASHBOARD
// =======================
async function dashboard(req, res) {
  try {
    const users = await query(
      `
      SELECT COUNT(*) AS total
      FROM users
      `
    );

    const activeUsers = await query(
      `
      SELECT COUNT(*) AS total
      FROM users
      WHERE is_active = TRUE
      `
    );

    const psychologists = await query(
      `
      SELECT COUNT(*) AS total
      FROM psychologists
      `
    );

    const verifiedPsychologists = await query(
      `
      SELECT COUNT(*) AS total
      FROM psychologists
      WHERE is_verified = TRUE
      `
    );

    const pendingPsychologists = await query(
      `
      SELECT COUNT(*) AS total
      FROM psychologists
      WHERE is_verified = FALSE
      `
    );

    const openAlerts = await query(
      `
      SELECT COUNT(*) AS total
      FROM risk_alerts
      WHERE status = 'open'
      `
    );

    const criticalAlerts = await query(
      `
      SELECT COUNT(*) AS total
      FROM risk_alerts
      WHERE status = 'open'
        AND risk_level = 'critique'
      `
    );

    const conversations = await query(
      `
      SELECT COUNT(*) AS total
      FROM conversations
      `
    );

    const appointments = await query(
      `
      SELECT COUNT(*) AS total
      FROM appointments
      `
    );

    const paidPayments = await query(
      `
      SELECT COUNT(*) AS total
      FROM payments
      WHERE status = 'paid'
      `
    );

    const pendingPayments = await query(
      `
      SELECT COUNT(*) AS total
      FROM payments
      WHERE status = 'pending'
      `
    );

    const revenue = await query(
      `
      SELECT COALESCE(SUM(amount), 0) AS total
      FROM payments
      WHERE status = 'paid'
      `
    );

    const recentUsers = await query(
      `
      SELECT
        id,
        full_name,
        email,
        city,
        risk_level,
        created_at
      FROM users
      ORDER BY created_at DESC
      LIMIT 5
      `
    );

    const recentAlerts = await query(
      `
      SELECT
        ra.*,
        u.full_name,
        u.email,
        u.phone
      FROM risk_alerts ra
      JOIN users u ON u.id = ra.user_id
      ORDER BY ra.created_at DESC
      LIMIT 5
      `
    );

    return res.json({
      success: true,
      stats: {
        users: users[0].total,
        active_users: activeUsers[0].total,

        psychologists: psychologists[0].total,
        verified_psychologists: verifiedPsychologists[0].total,
        pending_psychologists: pendingPsychologists[0].total,

        open_alerts: openAlerts[0].total,
        critical_alerts: criticalAlerts[0].total,

        conversations: conversations[0].total,
        appointments: appointments[0].total,

        paid_payments: paidPayments[0].total,
        pending_payments: pendingPayments[0].total,
        revenue: revenue[0].total,
      },
      recent_users: recentUsers,
      recent_alerts: recentAlerts,
    });
  } catch (error) {
    console.error("Erreur dashboard:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur dashboard",
      error: error.message,
    });
  }
}

// =======================
// LIST USERS
// =======================
async function listUsers(req, res) {
  try {
    const users = await query(
      `
      SELECT
        id,
        full_name,
        email,
        phone,
        birth_date,
        gender,
        city,
        country,
        preferred_language,
        addiction_type,
        consumption_level,
        risk_level,
        is_active,
        is_verified,
        created_at,
        updated_at
      FROM users
      ORDER BY created_at DESC
      `
    );

    return res.json({
      success: true,
      users,
    });
  } catch (error) {
    console.error("Erreur listUsers:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération users",
      error: error.message,
    });
  }
}

// =======================
// GET USER DETAIL ADMIN
// =======================
async function getUserDetail(req, res) {
  try {
    const { id } = req.params;

    const users = await query(
      `
      SELECT
        id,
        full_name,
        email,
        phone,
        birth_date,
        gender,
        city,
        country,
        preferred_language,
        addiction_type,
        consumption_level,
        risk_level,
        is_active,
        is_verified,
        created_at,
        updated_at
      FROM users
      WHERE id = ?
      `,
      [id]
    );

    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    const questionnaires = await query(
      `
      SELECT *
      FROM questionnaires
      WHERE user_id = ?
      ORDER BY created_at DESC
      `,
      [id]
    );

    const conversations = await query(
      `
      SELECT *
      FROM conversations
      WHERE user_id = ?
      ORDER BY started_at DESC
      `,
      [id]
    );

    const alerts = await query(
      `
      SELECT *
      FROM risk_alerts
      WHERE user_id = ?
      ORDER BY created_at DESC
      `,
      [id]
    );

    const appointments = await query(
      `
      SELECT
        a.*,
        p.full_name AS psychologist_name
      FROM appointments a
      LEFT JOIN psychologists p ON p.id = a.psychologist_id
      WHERE a.user_id = ?
      ORDER BY a.appointment_date DESC
      `,
      [id]
    );

    return res.json({
      success: true,
      user: users[0],
      questionnaires,
      conversations,
      alerts,
      appointments,
    });
  } catch (error) {
    console.error("Erreur getUserDetail:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur détail user",
      error: error.message,
    });
  }
}

// =======================
// DISABLE USER
// =======================
async function disableUser(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE users
      SET is_active = FALSE
      WHERE id = ?
      `,
      [id]
    );

    return res.json({
      success: true,
      message: "Utilisateur désactivé avec succès",
    });
  } catch (error) {
    console.error("Erreur disableUser:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur désactivation user",
      error: error.message,
    });
  }
}

// =======================
// ENABLE USER
// =======================
async function enableUser(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE users
      SET is_active = TRUE
      WHERE id = ?
      `,
      [id]
    );

    return res.json({
      success: true,
      message: "Utilisateur activé avec succès",
    });
  } catch (error) {
    console.error("Erreur enableUser:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur activation user",
      error: error.message,
    });
  }
}

// =======================
// LIST PSYCHOLOGISTS
// =======================
async function listPsychologists(req, res) {
  try {
    const psychologists = await query(
      `
      SELECT
        id,
        full_name,
        email,
        phone,
        license_number,
        specialization,
        experience_years,
        city,
        country,
        languages,
        accepts_online,
        accepts_in_person,
        consultation_price,
        currency,
        max_active_cases,
        current_active_cases,
        rating,
        is_verified,
        is_active,
        created_at,
        updated_at
      FROM psychologists
      ORDER BY created_at DESC
      `
    );

    return res.json({
      success: true,
      psychologists,
    });
  } catch (error) {
    console.error("Erreur listPsychologists:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération psychologues",
      error: error.message,
    });
  }
}

// =======================
// GET PSYCHOLOGIST DETAIL
// =======================
async function getPsychologistDetail(req, res) {
  try {
    const { id } = req.params;

    const psychologists = await query(
      `
      SELECT
        id,
        full_name,
        email,
        phone,
        license_number,
        specialization,
        experience_years,
        city,
        country,
        languages,
        accepts_online,
        accepts_in_person,
        consultation_price,
        currency,
        max_active_cases,
        current_active_cases,
        rating,
        is_verified,
        is_active,
        created_at,
        updated_at
      FROM psychologists
      WHERE id = ?
      `,
      [id]
    );

    if (psychologists.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Psychologue introuvable",
      });
    }

    const patients = await query(
      `
      SELECT
        pa.*,
        u.full_name,
        u.email,
        u.phone,
        u.risk_level
      FROM psychologist_assignments pa
      JOIN users u ON u.id = pa.user_id
      WHERE pa.psychologist_id = ?
      ORDER BY pa.start_date DESC
      `,
      [id]
    );

    const appointments = await query(
      `
      SELECT
        a.*,
        u.full_name AS user_name,
        u.email AS user_email
      FROM appointments a
      JOIN users u ON u.id = a.user_id
      WHERE a.psychologist_id = ?
      ORDER BY a.appointment_date DESC
      `,
      [id]
    );

    return res.json({
      success: true,
      psychologist: psychologists[0],
      patients,
      appointments,
    });
  } catch (error) {
    console.error("Erreur getPsychologistDetail:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur détail psychologue",
      error: error.message,
    });
  }
}

// =======================
// VERIFY PSYCHOLOGIST
// =======================
async function verifyPsychologist(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE psychologists
      SET is_verified = TRUE
      WHERE id = ?
      `,
      [id]
    );

    await query(
      `
      INSERT INTO notifications (
        receiver_type,
        receiver_id,
        title,
        message,
        type,
        is_read
      )
      VALUES ('psychologist', ?, ?, ?, 'admin', FALSE)
      `,
      [
        id,
        "Compte validé",
        "Votre compte psychologue a été validé par l’administration.",
      ]
    );

    return res.json({
      success: true,
      message: "Psychologue validé avec succès",
    });
  } catch (error) {
    console.error("Erreur verifyPsychologist:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur validation psychologue",
      error: error.message,
    });
  }
}

// =======================
// DISABLE PSYCHOLOGIST
// =======================
async function disablePsychologist(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE psychologists
      SET is_active = FALSE
      WHERE id = ?
      `,
      [id]
    );

    return res.json({
      success: true,
      message: "Psychologue désactivé avec succès",
    });
  } catch (error) {
    console.error("Erreur disablePsychologist:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur désactivation psychologue",
      error: error.message,
    });
  }
}

// =======================
// ENABLE PSYCHOLOGIST
// =======================
async function enablePsychologist(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE psychologists
      SET is_active = TRUE
      WHERE id = ?
      `,
      [id]
    );

    return res.json({
      success: true,
      message: "Psychologue activé avec succès",
    });
  } catch (error) {
    console.error("Erreur enablePsychologist:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur activation psychologue",
      error: error.message,
    });
  }
}

// =======================
// LIST ALERTS
// =======================
async function listAlerts(req, res) {
  try {
    const alerts = await query(
      `
      SELECT
        ra.*,
        u.full_name,
        u.email,
        u.phone,
        u.city,
        u.risk_level AS user_risk_level
      FROM risk_alerts ra
      JOIN users u ON u.id = ra.user_id
      ORDER BY ra.created_at DESC
      `
    );

    return res.json({
      success: true,
      alerts,
    });
  } catch (error) {
    console.error("Erreur listAlerts:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération alertes",
      error: error.message,
    });
  }
}

// =======================
// CLOSE ALERT
// =======================
async function closeAlert(req, res) {
  try {
    const { id } = req.params;

    await query(
      `
      UPDATE risk_alerts
      SET status = 'closed',
          reviewed_by_admin_id = ?,
          reviewed_at = NOW()
      WHERE id = ?
      `,
      [req.auth.id, id]
    );

    return res.json({
      success: true,
      message: "Alerte fermée avec succès",
    });
  } catch (error) {
    console.error("Erreur closeAlert:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur fermeture alerte",
      error: error.message,
    });
  }
}

// =======================
// LIST PAYMENTS
// =======================
async function listPayments(req, res) {
  try {
    const payments = await query(
      `
      SELECT
        p.*,
        u.full_name AS user_name,
        u.email AS user_email,
        psy.full_name AS psychologist_name,
        pl.name AS plan_name
      FROM payments p
      LEFT JOIN users u ON u.id = p.user_id
      LEFT JOIN psychologists psy ON psy.id = p.psychologist_id
      LEFT JOIN plans pl ON pl.id = p.plan_id
      ORDER BY p.created_at DESC
      `
    );

    return res.json({
      success: true,
      payments,
    });
  } catch (error) {
    console.error("Erreur listPayments:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération paiements",
      error: error.message,
    });
  }
}

// =======================
// LIST APPOINTMENTS
// =======================
async function listAppointments(req, res) {
  try {
    const appointments = await query(
      `
      SELECT
        a.*,
        u.full_name AS user_name,
        u.email AS user_email,
        psy.full_name AS psychologist_name,
        psy.email AS psychologist_email
      FROM appointments a
      JOIN users u ON u.id = a.user_id
      JOIN psychologists psy ON psy.id = a.psychologist_id
      ORDER BY a.appointment_date DESC
      `
    );

    return res.json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error("Erreur listAppointments:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération rendez-vous",
      error: error.message,
    });
  }
}

// =======================
// LIST CONVERSATIONS
// =======================
async function listConversations(req, res) {
  try {
    const conversations = await query(
      `
      SELECT
        c.*,
        u.full_name,
        u.email,
        u.phone
      FROM conversations c
      JOIN users u ON u.id = c.user_id
      ORDER BY c.started_at DESC
      `
    );

    return res.json({
      success: true,
      conversations,
    });
  } catch (error) {
    console.error("Erreur listConversations:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur récupération conversations",
      error: error.message,
    });
  }
}

// =======================
// GET CONVERSATION DETAIL ADMIN
// =======================
async function getConversationDetailAdmin(req, res) {
  try {
    const { id } = req.params;

    const conversations = await query(
      `
      SELECT
        c.*,
        u.full_name,
        u.email,
        u.phone
      FROM conversations c
      JOIN users u ON u.id = c.user_id
      WHERE c.id = ?
      `,
      [id]
    );

    if (conversations.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Conversation introuvable",
      });
    }

    const messages = await query(
      `
      SELECT *
      FROM messages
      WHERE conversation_id = ?
      ORDER BY created_at ASC
      `,
      [id]
    );

    const analyses = await query(
      `
      SELECT *
      FROM nlp_analyses
      WHERE conversation_id = ?
      ORDER BY created_at ASC
      `,
      [id]
    );

    return res.json({
      success: true,
      conversation: conversations[0],
      messages,
      analyses,
    });
  } catch (error) {
    console.error("Erreur getConversationDetailAdmin:", error);

    return res.status(500).json({
      success: false,
      message: "Erreur détail conversation admin",
      error: error.message,
    });
  }
}

module.exports = {
  loginAdmin,
  getAdminProfile,
  dashboard,

  listUsers,
  getUserDetail,
  disableUser,
  enableUser,

  listPsychologists,
  getPsychologistDetail,
  verifyPsychologist,
  disablePsychologist,
  enablePsychologist,

  listAlerts,
  closeAlert,

  listPayments,
  listAppointments,

  listConversations,
  getConversationDetailAdmin,
};