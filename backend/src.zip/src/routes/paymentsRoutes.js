const express = require("express");

const {
  getPlans,
  createCheckout,
  getMyPayments,
  getMyPaymentById,
  getMyInvoices,
  markManualPaid,
  rejectPayment,
  getAllPaymentsAdmin,
  getMyPayouts,
  webhookPayment,
} = require("../controllers/paymentsController");

const {
  authRequired,
  requireRole,
} = require("../middleware/authMiddleware");

const router = express.Router();

// =======================
// PUBLIC ROUTES
// =======================

// Liste des plans publics
router.get("/plans", getPlans);

// Webhook paiement pour plus tard
router.post("/webhook/:provider", webhookPayment);

// =======================
// USER ROUTES
// =======================

// Créer paiement pour appointment_id ou plan_id
router.post(
  "/create-checkout",
  authRequired,
  requireRole("USER"),
  createCheckout
);

// Mes paiements
router.get(
  "/me",
  authRequired,
  requireRole("USER"),
  getMyPayments
);

// Détail d’un paiement
router.get(
  "/me/:id",
  authRequired,
  requireRole("USER"),
  getMyPaymentById
);

// Mes factures
router.get(
  "/invoices/me",
  authRequired,
  requireRole("USER"),
  getMyInvoices
);

// =======================
// PSYCHOLOGIST ROUTES
// =======================

// Revenus / payouts du psychologue connecté
router.get(
  "/psychologist/payouts/me",
  authRequired,
  requireRole("PSYCHOLOGIST"),
  getMyPayouts
);

// =======================
// ADMIN ROUTES
// =======================

// Tous les paiements
router.get(
  "/admin/all",
  authRequired,
  requireRole("ADMIN", "SUPER_ADMIN"),
  getAllPaymentsAdmin
);

// Valider paiement manuel
router.patch(
  "/:id/manual-paid",
  authRequired,
  requireRole("ADMIN", "SUPER_ADMIN"),
  markManualPaid
);

// Refuser paiement
router.patch(
  "/:id/reject",
  authRequired,
  requireRole("ADMIN", "SUPER_ADMIN"),
  rejectPayment
);

module.exports = router;