const express = require("express");

const {
  createAppointment,
  getMyAppointments,
  getMyAppointmentById,
  cancelMyAppointment,
  getPsychologistAppointments,
  getPsychologistAppointmentById,
  updateAppointmentStatus,
  getAllAppointmentsAdmin,
} = require("../controllers/appointmentsController");

const {
  authRequired,
  requireRole,
} = require("../middleware/authMiddleware");

const router = express.Router();

// =======================
// USER ROUTES
// =======================

// Créer un rendez-vous avec un psychologue affecté
router.post(
  "/",
  authRequired,
  requireRole("USER"),
  createAppointment
);

// Mes rendez-vous user
router.get(
  "/me",
  authRequired,
  requireRole("USER"),
  getMyAppointments
);

// Détail d’un rendez-vous user
router.get(
  "/me/:id",
  authRequired,
  requireRole("USER"),
  getMyAppointmentById
);

// Annuler un rendez-vous user
router.patch(
  "/:id/cancel",
  authRequired,
  requireRole("USER"),
  cancelMyAppointment
);

// =======================
// PSYCHOLOGIST ROUTES
// =======================

// Rendez-vous du psychologue connecté
router.get(
  "/psychologist/me",
  authRequired,
  requireRole("PSYCHOLOGIST"),
  getPsychologistAppointments
);

// Détail rendez-vous psychologue
router.get(
  "/psychologist/me/:id",
  authRequired,
  requireRole("PSYCHOLOGIST"),
  getPsychologistAppointmentById
);

// Changer statut rendez-vous
router.patch(
  "/:id/status",
  authRequired,
  requireRole("PSYCHOLOGIST"),
  updateAppointmentStatus
);

// =======================
// ADMIN ROUTES
// =======================

// Tous les rendez-vous
router.get(
  "/admin/all",
  authRequired,
  requireRole("ADMIN", "SUPER_ADMIN"),
  getAllAppointmentsAdmin
);

module.exports = router;