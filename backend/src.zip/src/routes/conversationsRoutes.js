const express = require("express");

const {
  startConversation,
  sendMessage,
  getMyConversations,
  getConversationById,
  closeConversation,
} = require("../controllers/conversationsController");

const {
  authRequired,
  requireRole,
} = require("../middleware/authMiddleware");

const router = express.Router();

// =======================
// USER CONVERSATION ROUTES
// =======================

// Créer une conversation
router.post(
  "/start",
  authRequired,
  requireRole("USER"),
  startConversation
);

// Envoyer message dans conversation
// Node.js sauvegarde + appelle Python /nlp + /chat
router.post(
  "/message",
  authRequired,
  requireRole("USER"),
  sendMessage
);

// Récupérer toutes mes conversations
router.get(
  "/",
  authRequired,
  requireRole("USER"),
  getMyConversations
);

// Récupérer détail conversation avec messages + analyses NLP
router.get(
  "/:id",
  authRequired,
  requireRole("USER"),
  getConversationById
);

// Fermer conversation
router.patch(
  "/:id/close",
  authRequired,
  requireRole("USER"),
  closeConversation
);

module.exports = router;