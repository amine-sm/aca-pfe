const NLP_SERVICE_URL = process.env.NLP_SERVICE_URL || "http://127.0.0.1:8000";

async function checkPythonService() {
  const response = await fetch(`${NLP_SERVICE_URL}/`);

  if (!response.ok) {
    throw new Error(`FastAPI indisponible : ${response.status}`);
  }

  return response.json();
}

async function analyzeMessageWithPython(message, questionnaire = {}) {
  const response = await fetch(`${NLP_SERVICE_URL}/nlp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message,
      questionnaire: questionnaire || {},
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`FastAPI /nlp error ${response.status}: ${text}`);
  }

  return response.json();
}

async function generateReplyWithPython({
  message,
  summary_context = "",
  emotional_state = "stable",
  risk_level = "faible",
}) {
  const response = await fetch(`${NLP_SERVICE_URL}/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message,
      summary_context,
      emotional_state,
      risk_level,
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`FastAPI /chat error ${response.status}: ${text}`);
  }

  return response.json();
}

module.exports = {
  checkPythonService,
  analyzeMessageWithPython,
  generateReplyWithPython,
};